#!/usr/bin/env python

from distutils.core import setup

setup(name='myUniqueAnalytics',
      version='1.0dev',
      description='Python setup test',
      
      author='YDD9',
      author_email='YDD9@unknown.org',
      url='https://github.com/YDD9/testTodelete.git/',
      packages=['analytics'],
      long_description=open('README.mk').read(),
     )